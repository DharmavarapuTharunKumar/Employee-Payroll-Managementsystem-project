package com.employee_payroll.Exceptions;

public class CustomException extends RuntimeException {

    /**
	 * 
	 */
    // SerialVersionUID for version control of serialization
	private static final long serialVersionUID = 1L;

    // Constructor with a message
	public CustomException(String message) {
        super(message);
    }
    // Constructor with a message and a cause
    public CustomException(String message, Throwable cause) {
        super(message, cause);
    }
}
